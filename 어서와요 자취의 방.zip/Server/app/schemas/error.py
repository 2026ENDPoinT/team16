"""공통 error.code / error.message / error.detail JSON (Pydantic 모델 정의 예정)

TODO: API문서.md 계약에 맞춰 추후 구현한다.
현재 이 모듈에는 실행되는 비즈니스 기능이 없다.
"""
